<!-- Header Container
================================================== -->
<header id="header-container" class="fullwidth ">

    <!-- Header -->
    <div id="header">
        <div class="container">
            
            <!-- User Menu -->
            <div class="header-widget">
                <h1>Juan Jose Martinez</h1>

                <!-- Messages -->
                <div class="header-notifications user-menu">
                    <!-- <div class="header-notifications-trigger">
                        <a href="#"><div class="user-avatar"><img src="images/icon.png" alt=""></div></a>
                    </div>

                    <div class="header-notifications-dropdown"> 
                        <ul class="user-menu-small-nav">
                            <li><a href="index.php"><i class="icon-material-outline-dashboard"></i> Logout</a></li>
                        </ul>
                    </div> -->
                </div>

            </div>
            <!-- User Menu / End -->
                
        </div>
    </div>
    <!-- Header / End -->

</header>
<div class="clearfix"></div>
<!-- Header Container / End -->